package bank;

public class Account {
	private int nID;				//���� ��ȣ 
	private int nBalance;			//���� �ܰ� 
	private String strAccountName;	//���� �� 
	private String strPassword;		//���� ��й�ȣ 
	
	public Account(int id, int money, String name, String password) {
		this.nID=id;
		this.nBalance=money;
		this.strAccountName=name;
		this.strPassword=password;
	}
	
	boolean authenticate(int id, String passwd) {//���� Ȯ��
		return ((this.nID == id) && (this.strPassword.equals(passwd)));
	}
	public int getID() {
		return nID;
	}
	
	public int getnBalance() {
		return nBalance;
	}
	int deposit(int money) {		//�Ա�
		this.nBalance += money;
		return this.nBalance;
	}
	public int widraw(int money) {	//��� 
		this.nBalance -= money;
		return this.nBalance;
	}
	public boolean updatePasswd(String oldPasswd, String newPasswd) {  //��й�ȣ ����
		if(this.strPassword.equals(oldPasswd)) {
			this.strPassword=newPasswd;
			return true;
		}
		return false;
	}
	public String getAccountName() {    //���� �� �б�
		return strAccountName;
	}
}
