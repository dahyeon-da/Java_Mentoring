package util;

import bank.Account;
import java.util.Scanner;

public class Statistics {
	Scanner scan=new Scanner(System.in);
	public static int sum(Account [] account, int size) {
		int sum=0;
		for(int i=0;i<size;i++) {
			sum+=account[i].getnBalance();
		}
		return sum;
	}
	public static double average(Account [] account, int size) {
		int average=0;
		average=sum(account, size)/size;
		return average;
	}
	public static int max(Account [] account, int size) {
		int max=account[0].getnBalance();
		for(int j=1;j<size;j++) {
			if(max<account[j].getnBalance()) {
				max=account[j].getnBalance();
			}
		}
		return max;
	}
	public static Account [] sort(Account [] account, int size) {
		for(int k=0;k<size-1;k++){
            for(int l=k+1;l<size;l++){
                if(account[k].getnBalance()<account[l].getnBalance()){
                    Account tmp=account[k];
                    account[k]=account[l];
                    account[l]=tmp;
                }
            }
        }
		return account;
	}
}